<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<h1>Perkenalkan</h1>"
<p>Nama saya Raihan Permadi Saya tinggal di daerah Kalibata Olahraga yang saya sukai adalah Basket"</p>
