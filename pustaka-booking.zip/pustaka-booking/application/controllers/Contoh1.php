<?php
class Contoh1 extends CI_Controller
{
    public function index()
    {

        $this->load->view('viewcontoh1');
    }
}